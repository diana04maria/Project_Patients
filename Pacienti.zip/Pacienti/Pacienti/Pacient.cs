﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Pacienti
{
    public class Pacient
    {
        public string? Id { set; get; }
        public string? Nume { set; get; }
        public string? Adresa { set; get; }
        public string? Email { set; get; }
        public string? Varsta { set; get; }
        public string? Tratament { set; get; }
        public string? Diagnostic { set; get; }

        public override bool Equals(object? obj)
        {
            if(obj == null) { return false; }
            Pacient? p = obj as Pacient;
            return  Id == p.Id || 
                    Nume == p.Nume || 
                    Adresa == p.Adresa;
        }

        public override string ToString()
        {
            return $"Nume : {Nume} \n" +
                   $"Tratament : {Tratament}\n" +
                   $"Diagnostic {Diagnostic}";
        }
    }
}
