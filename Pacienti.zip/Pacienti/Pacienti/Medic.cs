﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pacienti
{
    public class Medic
    {
        public string? Id { set; get; }
        public string? Nume { set; get; }
        public string? Email { set; get; }

        public PacientList? ListaPacienti { set; get; }

        public override string ToString()
        {
            string p ="";
            foreach (Pacient pacient in ListaPacienti.Pacienti)
            {
                p += $"{pacient.ToString()}\n";
            }
            return $"Nume : {Nume} ; Email : {Email} ; Pacienti : \n{p}";
        }

    }
 }

