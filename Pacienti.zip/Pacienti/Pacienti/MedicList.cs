﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pacienti
{
    internal class MedicList
    {
        public List<Medic> Medici;
        public MedicList()
        {
            Medici = new List<Medic>();
        }
        public List<Medic> Add(Medic m)
        {
            Medici.Add(m);
            return Medici;
        }
        public List<Medic> Remove(Medic m)
        {
            Medici.Remove(m);
            return Medici;
        }
        public Medic SearchByName(string name)
        {
            Medic? M = Medici.Find(x => x.Nume == name);
            return M;
        }
        public Medic SearchByEmail(string email)
        {
            var M = Medici.Find(x => x.Email == email);
            return M;
        }
        public override string ToString()
        {
            return string.Join("\n", Medici);
        }
        public void SaveOnDisk()
        {
            var jsonPath = System.Configuration.ConfigurationManager.AppSettings["jsonSavePath"];
            string jsonString = JsonConvert.SerializeObject(Medici);
            File.WriteAllText($"{jsonPath}/medici.json", jsonString);
        }
        public List<Medic> LoadFromDisk()
        {
            var jsonPath = System.Configuration.ConfigurationManager.AppSettings["jsonSavePath"];
            if(!(File.Exists($"{jsonPath}/medici.json")))
            {
                return Medici;
            }
            var jsonString = File.ReadAllText($"{jsonPath}/medici.json");
            return JsonConvert.DeserializeObject<List<Medic>>(jsonString);
        }
    }
}
