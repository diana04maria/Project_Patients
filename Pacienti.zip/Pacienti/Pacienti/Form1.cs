namespace Pacienti
{
    public partial class Form1 : Form
    {
        PacientList? ListaPacienti;
        MedicList?   ListaMedici;

        public Form1()
        {
            ListaPacienti = new PacientList();
            ListaMedici = new MedicList();
            ListaMedici.Medici = ListaMedici.LoadFromDisk();
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(nume_pacient.Text))
            {
                MessageBox.Show("Campul Nume pacient este obligatoriu", "Eroare");
                return;
            }
            foreach (Medic medic in ListaMedici.Medici)
            {
                if(medic.ListaPacienti.SearchByName(nume_pacient.Text) != null)
                {
                    result.Text = $"Pacient gasit :\n\n{medic.ListaPacienti.SearchByName(nume_pacient.Text).ToString()}";
                    return;
                }
            }
            result.Text = $"Nu am gasit pacientul cu numele {nume_pacient.Text}";
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(String.IsNullOrEmpty(id_pacient.Text))
            {
                MessageBox.Show("Campul ID pacient este obligatoriu", "Eroare");
                return;
            }
            if (String.IsNullOrEmpty(nume_pacient.Text))
            {
                MessageBox.Show("Campul Nume pacient este obligatoriu", "Eroare");
                return;
            }
            if (String.IsNullOrEmpty(adresa_pacient.Text))
            {
                MessageBox.Show("Campul Adresa pacient este obligatoriu", "Eroare");
                return;
            }
            if (String.IsNullOrEmpty(email_pacient.Text))
            {
                MessageBox.Show("Campul Email pacient este obligatoriu", "Eroare");
                return;
            }
            if (String.IsNullOrEmpty(varsta_pacient.Text))
            {
                MessageBox.Show("Campul Varsta pacient este obligatoriu", "Eroare");
                return;
            }
            if (String.IsNullOrEmpty(tratament_pacient.Text))
            {
                MessageBox.Show("Campul Tratament pacient este obligatoriu", "Eroare");
                return;
            }
            if (String.IsNullOrEmpty(diagnostic_pacient.Text))
            {
                MessageBox.Show("Campul Diagnostic pacient este obligatoriu", "Eroare");
                return;
            }
            if (String.IsNullOrEmpty(nume_medic.Text))
            {
                MessageBox.Show("Campul Nume medic este obligatoriu", "Eroare");
                return;
            }
            if(ListaMedici.SearchByName(nume_medic.Text) == null)
            {
                ListaPacienti = new PacientList();
                MessageBox.Show("Medicul nu exista", "Eroare");
                return;
            }
            ListaPacienti = ListaMedici.SearchByName(nume_medic.Text).ListaPacienti;

            Pacient P = new Pacient
            {
                Id = id_pacient.Text,
                Nume = nume_pacient.Text,
                Adresa = adresa_pacient.Text,
                Email = email_pacient.Text,
                Tratament = tratament_pacient.Text,
                Varsta = varsta_pacient.Text,
                Diagnostic = diagnostic_pacient.Text
            };

            ListaPacienti.Add(P);
            button2.PerformClick();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(id_medic.Text))
            {
                MessageBox.Show("Campul ID medic este obligatoriu", "Eroare");
                return;
            }
            if (String.IsNullOrEmpty(nume_medic.Text))
            {
                MessageBox.Show("Campul Nume medic este obligatoriu", "Eroare");
                return;
            }
            if (String.IsNullOrEmpty(email_medic.Text))
            {
                MessageBox.Show("Campul Email medic este obligatoriu", "Eroare");
                return;
            }
            if (ListaMedici.SearchByName(nume_medic.Text) == null)
            {
                Medic M = new Medic
                {
                    Id = id_medic.Text,
                    Nume = nume_medic.Text,
                    Email = email_medic.Text,
                    ListaPacienti = ListaPacienti
                };
                ListaMedici.Add(M);
            }
            result.Text = $"Lista actualizata :\n\n{ListaMedici.ToString()}";
            ListaMedici.SaveOnDisk();
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(email_pacient.Text))
            {
                MessageBox.Show("Campul Email pacient este obligatoriu", "Eroare");
                return;
            }
            foreach (Medic medic in ListaMedici.Medici)
            {
                if (medic.ListaPacienti.SearchByEmail(email_pacient.Text) != null)
                {
                    result.Text = $"Pacient gasit :\n\n{medic.ListaPacienti.SearchByName(email_pacient.Text).ToString()}";
                    return;
                }
            }
            result.Text = $"Nu am gasit pacientul cu email-ul {email_pacient.Text}";

        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(nume_medic.Text))
            {
                MessageBox.Show("Campul Nume medic este obligatoriu", "Eroare");
                return;
            }
            var medic = ListaMedici.SearchByName(nume_medic.Text);
            if(medic != null)
            {
                result.Text = $"Medic gasit :\n\n{medic.ToString()}";
                return;
            }
            result.Text = $"Nu am gasit medicul cu numele {nume_medic.Text}";

        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(email_medic.Text))
            {
                MessageBox.Show("Campul Email medic este obligatoriu", "Eroare");
                return;
            }
            var medic = ListaMedici.SearchByEmail(email_medic.Text);
            if (medic != null)
            {
                result.Text = $"Medic gasit :\n\n{medic.ToString()}";
                return;
            }
            result.Text = $"Nu am gasit medicul cu email-ul {email_medic.Text}";

        }
    }
}