﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pacienti
{
    public class PacientList
    {
        public List<Pacient> Pacienti;
        public PacientList()
        {
            Pacienti = new List<Pacient>();
        }
        public List<Pacient> Add(Pacient p)
        {
            Pacienti.Add(p);
            return Pacienti;
        }
        public List<Pacient> Remove(Pacient p)
        {
            Pacienti.Remove(p);
            return Pacienti;
        }
        public Pacient SearchByName(string name)
        {
            var P = Pacienti.Find(x => x.Nume == name);
            return P;   
        }
        public Pacient SearchByEmail(string email)
        {
            var P = Pacienti.Find(x => x.Email == email);
            return P;
        }
        public override string ToString()
        {
            return string.Join("\n", Pacienti);
        }
    }
}
