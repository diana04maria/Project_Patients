﻿namespace Pacienti
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.id_pacient = new System.Windows.Forms.TextBox();
            this.nume_pacient = new System.Windows.Forms.TextBox();
            this.adresa_pacient = new System.Windows.Forms.TextBox();
            this.email_pacient = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tratament_pacient = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.diagnostic_pacient = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.email_medic = new System.Windows.Forms.TextBox();
            this.nume_medic = new System.Windows.Forms.TextBox();
            this.id_medic = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.result = new System.Windows.Forms.RichTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.varsta_pacient = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // id_pacient
            // 
            this.id_pacient.Location = new System.Drawing.Point(90, 125);
            this.id_pacient.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.id_pacient.Name = "id_pacient";
            this.id_pacient.Size = new System.Drawing.Size(164, 31);
            this.id_pacient.TabIndex = 0;
            // 
            // nume_pacient
            // 
            this.nume_pacient.Location = new System.Drawing.Point(90, 176);
            this.nume_pacient.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.nume_pacient.Name = "nume_pacient";
            this.nume_pacient.Size = new System.Drawing.Size(164, 31);
            this.nume_pacient.TabIndex = 1;
            // 
            // adresa_pacient
            // 
            this.adresa_pacient.Location = new System.Drawing.Point(90, 228);
            this.adresa_pacient.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.adresa_pacient.Name = "adresa_pacient";
            this.adresa_pacient.Size = new System.Drawing.Size(164, 31);
            this.adresa_pacient.TabIndex = 2;
            // 
            // email_pacient
            // 
            this.email_pacient.Location = new System.Drawing.Point(90, 285);
            this.email_pacient.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.email_pacient.Name = "email_pacient";
            this.email_pacient.Size = new System.Drawing.Size(164, 31);
            this.email_pacient.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 125);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "ID";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(-1, 176);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 25);
            this.label2.TabIndex = 5;
            this.label2.Text = "NUME";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(-1, 234);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "ADRESA";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(-1, 288);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 25);
            this.label4.TabIndex = 7;
            this.label4.Text = "EMAIL";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(-1, 402);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 25);
            this.label5.TabIndex = 9;
            this.label5.Text = "TRATAMENT";
            // 
            // tratament_pacient
            // 
            this.tratament_pacient.Location = new System.Drawing.Point(119, 396);
            this.tratament_pacient.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.tratament_pacient.Name = "tratament_pacient";
            this.tratament_pacient.Size = new System.Drawing.Size(135, 31);
            this.tratament_pacient.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(-1, 446);
            this.label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 25);
            this.label6.TabIndex = 11;
            this.label6.Text = "DIAGNOSTIC";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // diagnostic_pacient
            // 
            this.diagnostic_pacient.Location = new System.Drawing.Point(119, 439);
            this.diagnostic_pacient.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.diagnostic_pacient.Name = "diagnostic_pacient";
            this.diagnostic_pacient.Size = new System.Drawing.Size(135, 31);
            this.diagnostic_pacient.TabIndex = 10;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(700, 179);
            this.label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 25);
            this.label7.TabIndex = 17;
            this.label7.Text = "EMAIL";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(700, 131);
            this.label8.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 25);
            this.label8.TabIndex = 16;
            this.label8.Text = "NUME";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(716, 77);
            this.label9.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(30, 25);
            this.label9.TabIndex = 15;
            this.label9.Text = "ID";
            // 
            // email_medic
            // 
            this.email_medic.Location = new System.Drawing.Point(760, 173);
            this.email_medic.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.email_medic.Name = "email_medic";
            this.email_medic.Size = new System.Drawing.Size(149, 31);
            this.email_medic.TabIndex = 14;
            // 
            // nume_medic
            // 
            this.nume_medic.Location = new System.Drawing.Point(760, 128);
            this.nume_medic.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.nume_medic.Name = "nume_medic";
            this.nume_medic.Size = new System.Drawing.Size(149, 31);
            this.nume_medic.TabIndex = 13;
            // 
            // id_medic
            // 
            this.id_medic.Location = new System.Drawing.Point(745, 77);
            this.id_medic.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.id_medic.Name = "id_medic";
            this.id_medic.Size = new System.Drawing.Size(164, 31);
            this.id_medic.TabIndex = 12;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(266, 25);
            this.button1.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(209, 51);
            this.button1.TabIndex = 18;
            this.button1.Text = "ADAUGARE PACIENT";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(485, 25);
            this.button2.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(205, 51);
            this.button2.TabIndex = 19;
            this.button2.Text = "ADAUGARE MEDIC";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(280, 88);
            this.button3.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(195, 62);
            this.button3.TabIndex = 20;
            this.button3.Text = "CAUTARE PACIENT\r\n(NUME)";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(280, 160);
            this.button4.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(195, 61);
            this.button4.TabIndex = 21;
            this.button4.Text = "CAUTARE PACIENT\r\n(EMAIL)";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(485, 160);
            this.button5.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(205, 61);
            this.button5.TabIndex = 23;
            this.button5.Text = "CAUTARE MEDIC\r\n(EMAIL)";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(485, 88);
            this.button6.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(205, 62);
            this.button6.TabIndex = 22;
            this.button6.Text = "CAUTARE MEDIC\r\n(NUME)";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // result
            // 
            this.result.BackColor = System.Drawing.Color.MistyRose;
            this.result.Location = new System.Drawing.Point(266, 234);
            this.result.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(655, 300);
            this.result.TabIndex = 24;
            this.result.Text = "";
            this.result.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(-1, 343);
            this.label10.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(75, 25);
            this.label10.TabIndex = 26;
            this.label10.Text = "VARSTA";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // varsta_pacient
            // 
            this.varsta_pacient.Location = new System.Drawing.Point(90, 340);
            this.varsta_pacient.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.varsta_pacient.Name = "varsta_pacient";
            this.varsta_pacient.Size = new System.Drawing.Size(164, 31);
            this.varsta_pacient.TabIndex = 25;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(90, 25);
            this.label11.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 25);
            this.label11.TabIndex = 27;
            this.label11.Text = "PACIENTI";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(796, 25);
            this.label12.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(71, 25);
            this.label12.TabIndex = 28;
            this.label12.Text = "MEDICI";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(935, 549);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.varsta_pacient);
            this.Controls.Add(this.result);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.email_medic);
            this.Controls.Add(this.nume_medic);
            this.Controls.Add(this.id_medic);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.diagnostic_pacient);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tratament_pacient);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.email_pacient);
            this.Controls.Add(this.adresa_pacient);
            this.Controls.Add(this.nume_pacient);
            this.Controls.Add(this.id_pacient);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox id_pacient;
        private TextBox nume_pacient;
        private TextBox adresa_pacient;
        private TextBox email_pacient;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox tratament_pacient;
        private Label label6;
        private TextBox diagnostic_pacient;
        private Label label7;
        private Label label8;
        private Label label9;
        private TextBox email_medic;
        private TextBox nume_medic;
        private TextBox id_medic;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private RichTextBox result;
        private Label label10;
        private TextBox varsta_pacient;
        private Label label11;
        private Label label12;
    }
}